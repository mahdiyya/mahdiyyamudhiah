export default function ({ $gtm }) {
  $gtm.init('GTM-MHN82JG')
}
